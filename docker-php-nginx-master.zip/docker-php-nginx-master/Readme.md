# Testando o Docker

## Subir aplica��o php usando Mysql

### Configurando o Mysql

### Configurando Nginx


## Fazendo deploy usando Jenkins
